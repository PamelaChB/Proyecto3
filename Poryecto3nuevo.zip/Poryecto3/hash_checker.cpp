#include <array>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <magic.h>
#include <openssl/evp.h>
#include <openssl/sha.h>

using namespace std;
namespace fs = std::filesystem;

// Función para calcular el hash SHA-256 de un string (sin imprimir el contenido)
string calcularHashSHA256(const string &contenido) {
  // Iniciar el cronómetro
  auto inicio = chrono::high_resolution_clock::now();

  unsigned char hash[SHA256_DIGEST_LENGTH];
  EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
  EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL);

  // Convertir el string a un array de bytes
  unsigned char *contentBytes = reinterpret_cast<unsigned char *>(
      const_cast<char *>(contenido.c_str()));

  EVP_DigestUpdate(mdctx, contentBytes, contenido.size());
  EVP_DigestFinal_ex(mdctx, hash, NULL);
  EVP_MD_CTX_free(mdctx);

  string hashString;
  for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
    char buffer[3];
    sprintf(buffer, "%02x", hash[i]);
    hashString += buffer;
  }

  // Detener el cronómetro
  auto fin = chrono::high_resolution_clock::now();
  auto duracion = chrono::duration_cast<chrono::milliseconds>(fin - inicio);

  // Mostrar información adicional (sin el contenido)
  cout << "Tamaño del contenido: " << contenido.size() << " bytes" << endl;
  cout << "Tiempo de cálculo del hash: " << duracion.count() << " ms" << endl;

  return hashString;
}

// Función para extraer el contenido de diferentes tipos de archivos usando
// libmagic (sin imprimir el contenido)
string extraerContenido(const string &nombreArchivo) {
  magic_t magic_cookie = magic_open(MAGIC_MIME_TYPE);
  if (magic_cookie == NULL) {
    cerr << "Error al inicializar libmagic." << endl;
    return "";
  }
  if (magic_load(magic_cookie, NULL) != 0) {
    cerr << "Error al cargar la base de datos de magic: "
         << magic_error(magic_cookie) << endl;
    magic_close(magic_cookie);
    return "";
  }

  const char *mime_type = magic_file(magic_cookie, nombreArchivo.c_str());
  if (mime_type == NULL) {
    cerr << "Error al obtener el tipo MIME del archivo: "
         << magic_error(magic_cookie) << endl;
    magic_close(magic_cookie);
    return "";
  }

  string resultado;
  if (string(mime_type) == "application/pdf") {
    // Extraer texto de PDF usando pdftotext
    string comando = "pdftotext " + nombreArchivo + " -";
    array<char, 128> buffer;
    FILE *pipe = popen(comando.c_str(), "r");
    if (!pipe) {
      cerr << "Error al ejecutar pdftotext." << endl;
      magic_close(magic_cookie);
      return "";
    }
    while (fgets(buffer.data(), 128, pipe) != nullptr) {
      resultado += buffer.data();
    }
    pclose(pipe);
  } else if (string(mime_type) ==
             "application/vnd.openxmlformats-officedocument."
             "wordprocessingml.document") {
    // Extraer texto de DOCX usando docx2txt
    string comando = "docx2txt " + nombreArchivo + " -";
    array<char, 128> buffer;
    FILE *pipe = popen(comando.c_str(), "r");
    if (!pipe) {
      cerr << "Error al ejecutar docx2txt." << endl;
      magic_close(magic_cookie);
      return "";
    }
    while (fgets(buffer.data(), 128, pipe) != nullptr) {
      resultado += buffer.data();
    }
    pclose(pipe);
  } else if (string(mime_type) ==
             "application/vnd.openxmlformats-officedocument."
             "spreadsheetml.sheet") {
    // Extraer texto de XLSX usando xlsx2csv
    string comando = "xlsx2csv " + nombreArchivo + " -";
    array<char, 128> buffer;
    FILE *pipe = popen(comando.c_str(), "r");
    if (!pipe) {
      cerr << "Error al ejecutar xlsx2csv." << endl;
      magic_close(magic_cookie);
      return "";
    }
    while (fgets(buffer.data(), 128, pipe) != nullptr) {
      resultado += buffer.data();
    }
    pclose(pipe);
  } else if (string(mime_type).find("image/") == 0) {
    // Para imágenes, usar un hash del contenido binario
    ifstream archivo(nombreArchivo, ios::binary);
    if (archivo.is_open()) {
      char byte;
      while (archivo.get(byte)) {
        resultado += byte;
      }
      archivo.close();
    } else {
      cerr << "Error al abrir el archivo de imagen." << endl;
    }
  } else if (string(mime_type) == "text/plain" ||
             string(mime_type) == "text/x-c" ||
             string(mime_type) == "text/x-c++" ||
             string(mime_type) == "text/x-python") {
    // Para archivos de texto, C++ y Python, leer el contenido directamente
    ifstream archivo(nombreArchivo);
    if (archivo.is_open()) {
      string linea;
      while (getline(archivo, linea)) {
        resultado += linea + "\n";
      }
      archivo.close();
    } else {
      cerr << "Error al abrir el archivo de texto." << endl;
    }
  } else {
    cout << "Formato de archivo no soportado." << endl;
  }

  magic_close(magic_cookie);
  return resultado;
}

int main() {
  while (true) {
    string nombreArchivoOriginal, nombreArchivoModificado;

    // Solicitar el nombre del archivo original
    cout << "Ingrese el nombre del archivo original: ";
    cin >> nombreArchivoOriginal;

    // Extraer el contenido del archivo original (texto o hash binario)
    string contenidoOriginal = extraerContenido(nombreArchivoOriginal);
    if (contenidoOriginal.empty()) {
      continue; // Volver al inicio si no se pudo extraer el contenido
    }

    // Calcular el hash del contenido original
    string hashOriginal = calcularHashSHA256(contenidoOriginal);
    cout << "Hash SHA-256 original: " << hashOriginal << endl;

    // Simulación de manipulación (editar el archivo manualmente)
    cout << "Modifique el archivo y presione Enter para continuar..." << endl;
    cin.get();
    cin.get();

    // Solicitar el nombre del archivo modificado
    cout << "Ingrese el nombre del archivo modificado: ";
    cin >> nombreArchivoModificado;

    // Verificar si el nombre del archivo modificado es el mismo que el original
    while (nombreArchivoModificado != nombreArchivoOriginal) {
      cout << "El nombre del archivo modificado no coincide con el original."
           << endl;
      cout << "Ingrese el nombre del archivo modificado nuevamente: ";
      cin >> nombreArchivoModificado;
    }

    // Extraer el contenido del archivo modificado (texto o hash binario)
    string contenidoModificado = extraerContenido(nombreArchivoModificado);
    if (contenidoModificado.empty()) {
      continue; // Volver al inicio si no se pudo extraer el contenido
    }

    // Calcular el hash del contenido modificado
    string hashModificado = calcularHashSHA256(contenidoModificado);
    cout << "Hash SHA-256 del archivo modificado: " << hashModificado << endl;

    // Comparar los hashes
    if (hashOriginal == hashModificado) {
      cout << "El archivo no ha sido modificado." << endl;
    } else {
      cout << "El archivo ha sido modificado." << endl;
    }

    // Preguntar si se desea analizar otro archivo
    char respuesta;
    cout << "¿Desea analizar otro archivo? (s/n): ";
    cin >> respuesta;
    if (respuesta != 's') {
      break;
    }
  }

  return 0;
}